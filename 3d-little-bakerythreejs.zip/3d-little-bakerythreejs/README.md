# 3D Little Bakery - ThreeJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/KKJBBRd](https://codepen.io/ricardoolivaalonso/pen/KKJBBRd).

